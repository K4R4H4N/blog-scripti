<!-- cikis yap-->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel">Çıkış yapmak istediğine emin misin?</h5>
<button class="close" type="button" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<div class="modal-body">Çıkış yaparsanız panele erişmek için tekrar giriş yapmanız gerekecektir.</div>
<div class="modal-footer">
<button class="btn btn-secondary" type="button" data-dismiss="modal">Vazgeç</button>
<a class="btn btn-primary" href="<?php echo base_url("admin/cikis"); ?>">Çıkış yap</a>
</div>
</div>
</div>
</div>